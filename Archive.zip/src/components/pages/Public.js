import React, { Component } from "react";


class Public extends Component {
    render() {
        return (
            <div>
                Public
            </div>
        )
    }
}
export default Public;
