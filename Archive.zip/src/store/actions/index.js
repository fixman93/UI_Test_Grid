export { 
    initIngredients,
    fetchPost
} from './Posts'